package com.alibaba;

import org.springframework.stereotype.Component;

@Component
public class SomeThingTest {

	public void fileTest() {

	}

	public static void main(String[] args) {
		// System.out.print(new
		// File("D:\\Eclipse_Workspace\\ShoppingMall\\WebContent\\img\\nova
		// 2\\曜石黑.png"));

		String s = "2G+16G";
		System.out.println(s.replace("G", ""));
	}

}
