package org.sang;

import org.springframework.stereotype.Service;

/**
 * Created by sang on 16-12-14.
 */
@Service
public class DemoBean {
    public void output() {
        System.out.println("襟三江而带五湖，控蛮荆而引瓯越");
    }
}
