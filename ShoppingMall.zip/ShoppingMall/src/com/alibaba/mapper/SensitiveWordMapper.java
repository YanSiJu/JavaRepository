package com.alibaba.mapper;

import java.util.List;
import com.alibaba.entity.SensitiveWord;

public interface SensitiveWordMapper {

	List<SensitiveWord> queryWord();

}
