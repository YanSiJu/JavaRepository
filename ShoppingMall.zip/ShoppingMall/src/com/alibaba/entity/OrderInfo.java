package com.alibaba.entity;

public class OrderInfo {

}
