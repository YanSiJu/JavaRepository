$(document).ready(function() {
	var submitBtn = $("#regist");
	submitBtn.onclick = function(event) {
		alert("check")
		
	};
})