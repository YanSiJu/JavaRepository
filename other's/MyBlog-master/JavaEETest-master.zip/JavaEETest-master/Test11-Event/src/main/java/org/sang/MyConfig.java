package org.sang;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created by sang on 16-12-13.
 */
@Configuration
@ComponentScan("org.sang")
public class MyConfig {
}
